# How to deploy?
[Watch video tutorial on deploying](https://youtu.be/gXXFpTAk6Vo)

# GroupManager

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2Fxditya%2Fgroupmanager)

A modular Telegram Python bot running on python3 with an sqlalchemy database.

Can be found on telegram as [GroupManager](https://t.me/tg_groupmanagerbot).

Alternatively, [find me on telegram](https://t.me/xditya)! (Keep all support questions in the support chat, where more people can help you.)

You can also join our support group [here!](https://t.me/tg_groupmanagerbot)

# Group
[Join Discuss Group](https://t.me/giveaways_24hrs)

# Report error
Report your problem along with your name to [this person](https://t.me/xditya)
